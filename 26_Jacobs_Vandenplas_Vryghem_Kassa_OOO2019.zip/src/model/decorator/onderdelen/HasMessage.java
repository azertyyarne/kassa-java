package model.decorator.onderdelen;

public interface HasMessage {
    void setMessage(String message);
}
