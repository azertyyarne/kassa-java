package model.decorator;

import model.Verkoop;

public abstract class DecoratorKassabon {

    public abstract String print(Verkoop verkoop);
}
