package model.decorator;

import model.Verkoop;

public class Kassabon extends DecoratorKassabon{

    @Override
    public String print(Verkoop verkoop){
        return "";
    }
}
