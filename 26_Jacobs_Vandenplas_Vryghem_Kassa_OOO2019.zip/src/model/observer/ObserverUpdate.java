package model.observer;

public interface ObserverUpdate {
    void update();
}
