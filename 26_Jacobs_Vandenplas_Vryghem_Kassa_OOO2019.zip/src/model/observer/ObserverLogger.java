package model.observer;

public interface ObserverLogger {
    void log();
}
