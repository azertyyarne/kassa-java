package model.observer;

public interface ObserverVerkoop {
    void afsluitMenu();
    void standardMenu();
}
